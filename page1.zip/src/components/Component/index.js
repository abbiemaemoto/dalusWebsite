export { Component } from "./Component";
