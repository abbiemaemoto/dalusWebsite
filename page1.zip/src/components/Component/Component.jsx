/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import "./style.css";

export const Component = ({ className }) => {
  return (
    <div className={`component ${className}`}>
      <div className="group">
        <div className="overlap">
          <div className="overlap-group">
            <div className="rectangle" />
            <div className="div" />
            <div className="rectangle-2" />
            <div className="rectangle-3" />
            <div className="ellipse" />
          </div>
          <img className="polygon" alt="Polygon" src="/img/polygon-1-2.svg" />
          <img className="img" alt="Polygon" src="/img/polygon-2-2.svg" />
        </div>
      </div>
    </div>
  );
};
