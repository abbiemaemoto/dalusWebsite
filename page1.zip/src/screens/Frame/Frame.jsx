import React from "react";
import { Component } from "../../components/Component";
import { ComponentWrapper } from "../../components/ComponentWrapper";
import "./style.css";

export const Frame = () => {
  return (
    <div className="frame">
      <div className="div-2">
        <div className="overlap-3">
          <div className="overlap-4">
            <div className="rectangle-8" />
            <p className="ideate-custom-use">
              <span className="text-wrapper">Ideate</span>
              <span className="span"> custom use cases for AI</span>
            </p>
            <div className="query">
              <div className="overlap-group-wrapper">
                <div className="overlap-5">
                  <Component className="component-instance" />
                  <div className="div-wrapper">
                    <p className="p">How do you currently do this?</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="query-wrapper">
              <div className="overlap-group-wrapper">
                <div className="overlap-6">
                  <ComponentWrapper className="component-instance" />
                  <div className="group-2">
                    <p className="text-wrapper-2">Great, I found the perfect tools for you!</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="img-wrapper">
              <img className="query-2" alt="Query" src="/img/query-1.png" />
            </div>
            <div className="query-3">
              <div className="query-4">
                <div className="group-wrapper">
                  <div className="group-3">
                    <img className="group-4" alt="Group" src="/img/group-60638.png" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <p className="text-wrapper-3">Supercharge Your Marketing Workflows in Minutes</p>
          <div className="demo">
            <div className="overlap-group-3">
              <div className="text-wrapper-4">Schedule a Demo</div>
              <img className="arrow" alt="Arrow" src="/img/arrow-1.svg" />
            </div>
          </div>
        </div>
        <div className="text-wrapper-5">Dalus AI</div>
        <div className="contact-us">
          <div className="overlap-7">
            <div className="rectangle-9" />
            <div className="text-wrapper-6">Contact Us</div>
          </div>
        </div>
        <div className="logo">
          <div className="overlap-8">
            <div className="rectangle-10" />
            <div className="rectangle-11" />
            <div className="rectangle-12" />
            <div className="rectangle-13" />
            <div className="ellipse-3" />
            <img className="polygon-4" alt="Polygon" src="/img/polygon-1-4.svg" />
            <img className="polygon-5" alt="Polygon" src="/img/polygon-2-4.svg" />
            <img className="subtract" alt="Subtract" src="/img/subtract.svg" />
          </div>
        </div>
      </div>
    </div>
  );
};
