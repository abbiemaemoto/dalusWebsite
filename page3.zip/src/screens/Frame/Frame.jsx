import React from "react";
import "./style.css";

export const Frame = () => {
  return (
    <div className="frame">
      <div className="div">
        <p className="integrate-new-tools">
          <span className="text-wrapper">Integrate</span>
          <span className="span"> new tools into existing workflows</span>
        </p>
        <p className="p">Supercharge Your Marketing Workflows in Minutes</p>
        <div className="demo">
          <div className="overlap-group">
            <div className="text-wrapper-2">Schedule a Demo</div>
            <img className="arrow" alt="Arrow" src="/img/arrow-1.svg" />
          </div>
        </div>
        <div className="contact-us">
          <div className="overlap">
            <div className="rectangle" />
            <div className="text-wrapper-3">Contact Us</div>
          </div>
        </div>
        <div className="text-wrapper-4">Dalus AI</div>
        <div className="group">
          <div className="overlap-2">
            <div className="rectangle-2" />
            <div className="rectangle-3" />
            <div className="rectangle-4" />
            <div className="rectangle-5" />
            <div className="ellipse" />
            <img className="polygon" alt="Polygon" src="/img/polygon-1.svg" />
            <img className="img" alt="Polygon" src="/img/polygon-2.svg" />
            <img className="subtract" alt="Subtract" src="/img/subtract.svg" />
          </div>
        </div>
        <div className="overlap-3">
          <div className="overlap-wrapper">
            <div className="div-wrapper">
              <div className="text-wrapper-5">Pilot</div>
            </div>
          </div>
          <div className="group-2">
            <div className="overlap-group-wrapper">
              <div className="overlap-group-2">
                <div className="ellipse-2" />
                <div className="ellipse-3" />
                <div className="ellipse-4" />
              </div>
            </div>
            <div className="text-wrapper-6">Start</div>
            <div className="text-wrapper-7">Full Deployment</div>
          </div>
          <div className="group-3">
            <div className="overlap-4">
              <div className="text-wrapper-8">Identify</div>
            </div>
          </div>
          <div className="group-4">
            <div className="overlap-5">
              <div className="text-wrapper-9">Integrate</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
