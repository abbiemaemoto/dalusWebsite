import React from "react";
import "./style.css";

export const Frame = () => {
  return (
    <div className="frame">
      <div className="div">
        <p className="improve-AI-literacy">
          <span className="text-wrapper">Improve</span>
          <span className="span"> AI literacy with personalized trainings</span>
        </p>
        <p className="p">Supercharge Your Marketing Workflows in Minutes</p>
        <div className="demo">
          <div className="overlap-group">
            <div className="text-wrapper-2">Schedule a Demo</div>
            <img className="arrow" alt="Arrow" src="/img/arrow-1.svg" />
          </div>
        </div>
        <div className="contact-us">
          <div className="overlap">
            <div className="rectangle" />
            <div className="text-wrapper-3">Contact Us</div>
          </div>
        </div>
        <div className="text-wrapper-4">Dalus AI</div>
        <div className="group">
          <div className="overlap-2">
            <div className="rectangle-2" />
            <div className="rectangle-3" />
            <div className="rectangle-4" />
            <div className="rectangle-5" />
            <div className="ellipse" />
            <img className="polygon" alt="Polygon" src="/img/polygon-1-1.svg" />
            <img className="img" alt="Polygon" src="/img/polygon-2-1.svg" />
            <img className="subtract" alt="Subtract" src="/img/subtract.svg" />
          </div>
        </div>
        <div className="overlap-3">
          <div className="group-2">
            <div className="rectangle-wrapper">
              <img className="rectangle-6" alt="Rectangle" src="/img/rectangle.png" />
            </div>
            <img className="juan-encalada" alt="Juan encalada" src="/img/juan-encalada-wc7kiho13fc-unsplash-1.png" />
          </div>
          <div className="overlap-wrapper">
            <div className="group-wrapper">
              <div className="overlap-group-wrapper">
                <div className="overlap-4">
                  <div className="overlap-group-2">
                    <div className="rectangle-7" />
                    <div className="rectangle-8" />
                    <div className="rectangle-9" />
                    <div className="rectangle-10" />
                    <div className="ellipse-2" />
                  </div>
                  <img className="polygon-2" alt="Polygon" src="/img/polygon-1.svg" />
                  <img className="polygon-3" alt="Polygon" src="/img/polygon-2.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="send-message-wrapper">
            <img className="send-message" alt="Send message" src="/img/send-message-1-1.png" />
          </div>
          <p className="text-wrapper-5">How do I improve ad image quality in Jasper Art?</p>
        </div>
      </div>
    </div>
  );
};
