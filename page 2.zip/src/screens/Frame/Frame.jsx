import React from "react";
import "./style.css";

export const Frame = () => {
  return (
    <div className="frame">
      <div className="div">
        <p className="identify-iterate">
          <span className="text-wrapper">Identify &amp; iterate</span>
          <span className="span"> with trusted AI tools</span>
        </p>
        <p className="p">Supercharge Your Marketing Workflows in Minutes</p>
        <div className="demo">
          <div className="overlap-group">
            <div className="text-wrapper-2">Schedule a Demo</div>
            <img className="arrow" alt="Arrow" src="/img/arrow-1.svg" />
          </div>
        </div>
        <div className="contact-us">
          <div className="overlap">
            <div className="rectangle" />
            <div className="text-wrapper-3">Contact Us</div>
          </div>
        </div>
        <div className="overlap-2">
          <div className="group">
            <div className="overlap-3">
              <img className="img" alt="Rectangle" src="/img/rectangle-1.png" />
              <img className="rectangle-2" alt="Rectangle" src="/img/rectangle.png" />
              <div className="text-wrapper-4">ChatGPT</div>
              <img className="image" alt="Image" src="/img/image-8.png" />
            </div>
          </div>
          <img className="group-2" alt="Group" src="/img/group-60646.png" />
        </div>
        <div className="text-wrapper-5">Dalus AI</div>
        <div className="overlap-wrapper">
          <div className="overlap-4">
            <div className="rectangle-3" />
            <div className="rectangle-4" />
            <div className="rectangle-5" />
            <div className="rectangle-6" />
            <div className="ellipse" />
            <img className="polygon" alt="Polygon" src="/img/polygon-1.svg" />
            <img className="polygon-2" alt="Polygon" src="/img/polygon-2.svg" />
            <img className="subtract" alt="Subtract" src="/img/subtract.svg" />
          </div>
        </div>
      </div>
    </div>
  );
};
